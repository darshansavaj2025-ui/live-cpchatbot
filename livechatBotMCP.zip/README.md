# Signal — a chatbot with an LLM brain, wired to a live MCP server

Built for the NCI individual exercise: *"Create a new chatbot (that has an LLM
brain!) and connect a live MCP to it. Deploy it to a live GitHub page."*

## What's in here

```
index.html            the chat UI
style.css             styling
app.js                all the logic: MCP client + Claude API tool-use loop
demo-mcp-server/       a tiny, deployable MCP server with 3 example tools
  server.js
  package.json
```

- **`index.html` / `style.css` / `app.js`** — this is the part you deploy to
  GitHub Pages. It's a static site: no build step, no backend.
- **`demo-mcp-server/`** — GitHub Pages can only serve static files, so your
  MCP server has to live somewhere else that can run Node.js. This folder is
  a small, ready-to-deploy example so you have something "live" to point the
  chatbot at.

## How it works

```
You (browser) ──▶ Claude API (the LLM brain) ──▶ your MCP server (tools)
```

1. You type a message. It's sent straight from your browser to the Anthropic
   Messages API, along with the list of tools your MCP server advertises.
2. If Claude decides a tool would help, it says so instead of just replying
   with text (`stop_reason: "tool_use"`).
3. The browser calls your MCP server directly (`tools/call` over Streamable
   HTTP/JSON-RPC), gets the result, and sends it back to Claude.
4. Claude reads the tool result and writes the final answer.

Everything runs client-side because GitHub Pages has no server to hide a
backend on. Two consequences worth knowing about:

- **The API key lives in the browser.** It's only kept in memory for the
  current tab (never saved to a file, never committed to the repo), and
  calls go straight from your browser to `api.anthropic.com` using the
  `anthropic-dangerous-direct-browser-access` header, which Anthropic added
  specifically for bring-your-own-key client-side apps like this one. Still,
  anyone who opens dev tools on your deployed page while you have a key
  typed in could read it — so treat it like a demo/personal-use key, not a
  production secret, and don't leave your own key in the page for others to
  find.
- **Your MCP server must allow CORS.** Browsers block cross-origin requests
  by default. The demo server in `demo-mcp-server/` already enables it.

## 1. Get a live MCP server running

Fastest path — deploy the included demo server:

```bash
cd demo-mcp-server
npm install
npm start        # confirms it works locally at http://localhost:3000/mcp
```

Then deploy it somewhere that runs Node.js continuously and gives you a
public URL, for example:

- **Render** (free web service): New → Web Service → connect this folder's
  repo → build command `npm install`, start command `npm start`.
- **Railway** or **Fly.io**: similar — point at `demo-mcp-server/`, it
  reads `PORT` from the environment automatically.

Once deployed, your MCP endpoint is `https://<your-app>.onrender.com/mcp`
(or equivalent). That's the "live MCP" the exercise asks for.

Prefer to build your own tools instead of the 3 demo ones (`get_time`,
`roll_dice`, `calculator`)? Edit `demo-mcp-server/server.js` — each tool is
just a `server.registerTool(name, { description, inputSchema }, handler)`
call.

## 2. Deploy the chatbot to GitHub Pages

1. Create a new GitHub repo and push these files (`index.html`, `style.css`,
   `app.js`) to the root of the `main` branch.
2. In the repo: **Settings → Pages → Source → Deploy from a branch**, pick
   `main` and `/ (root)`.
3. Wait a minute, then your chatbot is live at
   `https://<your-username>.github.io/<repo-name>/`.

## 3. Use it

1. Open your GitHub Pages URL.
2. Paste in your [Anthropic API key](https://console.anthropic.com/settings/keys).
3. Paste in your MCP server's URL (e.g. `https://<your-app>.onrender.com/mcp`).
4. Click **Wire it up** — you should see the available tools listed.
5. Chat normally. Try something like *"Roll 3 dice"* or *"What's 12 times
   (7 + 5)?"* to see it actually reach for a tool instead of guessing.

## Submitting

Share the GitHub Pages URL in the group chat as asked, and submit your repo
link (and anything else requested) via Moodle.
