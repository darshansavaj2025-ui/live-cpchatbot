// ============================================================================
// Signal — a chatbot with an LLM brain, wired to a live MCP tool server.
//
// Everything runs client-side (this has to work from a static GitHub Pages
// site with no backend). That means:
//   1. The Anthropic API key lives only in this tab's memory, and calls go
//      directly from the browser to api.anthropic.com using the
//      "anthropic-dangerous-direct-browser-access" header.
//   2. The MCP connection is a plain Streamable HTTP JSON-RPC client
//      (initialize -> tools/list -> tools/call), talking to whatever MCP
//      server URL you give it, as long as that server allows CORS.
// ============================================================================

const state = {
  apiKey: null,
  model: 'claude-sonnet-5',
  mcpUrl: null,
  mcpSessionId: null,
  tools: [],          // MCP tool defs, translated to Anthropic tool format
  mcpRequestId: 1,
  history: [],        // Anthropic message history
  connected: false,
};

const el = {
  apiKey: document.getElementById('api-key'),
  model: document.getElementById('model'),
  mcpUrl: document.getElementById('mcp-url'),
  connectBtn: document.getElementById('connect-btn'),
  connectStatus: document.getElementById('connect-status'),
  toolsList: document.getElementById('tools-list'),
  toolsUl: document.getElementById('tools-ul'),
  messages: document.getElementById('messages'),
  form: document.getElementById('chat-form'),
  input: document.getElementById('chat-input'),
  sendBtn: document.getElementById('send-btn'),
  nodeYou: document.getElementById('node-you'),
  nodeLlm: document.getElementById('node-llm'),
  nodeMcp: document.getElementById('node-mcp'),
  wire1: document.getElementById('wire-1'),
  wire2: document.getElementById('wire-2'),
};

// ---------------------------------------------------------------------------
// Tiny signal-path animation helpers (purely cosmetic, but also a genuinely
// useful "what is happening right now" indicator while you debug the wiring)
// ---------------------------------------------------------------------------
function pulse(node) {
  node.classList.add('active');
  setTimeout(() => node.classList.remove('active'), 700);
}
function fire(wire) {
  wire.classList.remove('firing');
  void wire.offsetWidth; // restart animation
  wire.classList.add('firing');
}

// ---------------------------------------------------------------------------
// MCP client (Streamable HTTP transport, JSON-RPC 2.0)
// Spec: https://modelcontextprotocol.io
// ---------------------------------------------------------------------------
async function mcpRequest(method, params, { expectResponse = true } = {}) {
  const body = { jsonrpc: '2.0', method, params: params || {} };
  if (expectResponse) body.id = state.mcpRequestId++;

  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json, text/event-stream',
  };
  if (state.mcpSessionId) headers['Mcp-Session-Id'] = state.mcpSessionId;

  const res = await fetch(state.mcpUrl, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
  });

  const sid = res.headers.get('Mcp-Session-Id');
  if (sid) state.mcpSessionId = sid;

  if (!expectResponse) return null;

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`MCP server returned ${res.status}: ${text.slice(0, 300)}`);
  }

  const contentType = res.headers.get('content-type') || '';

  if (contentType.includes('text/event-stream')) {
    const raw = await res.text();
    // Grab every "data: {...}" line and return the last JSON-RPC message
    const messages = raw
      .split('\n')
      .filter((l) => l.startsWith('data:'))
      .map((l) => l.slice(5).trim())
      .filter(Boolean)
      .map((l) => JSON.parse(l));
    const msg = messages[messages.length - 1];
    if (msg && msg.error) throw new Error(msg.error.message || 'MCP error');
    return msg ? msg.result : null;
  }

  const json = await res.json();
  if (json.error) throw new Error(json.error.message || 'MCP error');
  return json.result;
}

async function mcpConnect(url) {
  state.mcpUrl = url;
  state.mcpSessionId = null;
  state.mcpRequestId = 1;

  await mcpRequest('initialize', {
    protocolVersion: '2025-06-18',
    capabilities: {},
    clientInfo: { name: 'signal-chatbot', version: '1.0.0' },
  });

  // Notification: no id, no response expected
  await mcpRequest('notifications/initialized', {}, { expectResponse: false });

  const result = await mcpRequest('tools/list', {});
  const mcpTools = (result && result.tools) || [];

  // Translate MCP tool schema -> Anthropic tool schema
  state.tools = mcpTools.map((t) => ({
    name: t.name,
    description: t.description || '',
    input_schema: t.inputSchema || { type: 'object', properties: {} },
  }));

  return state.tools;
}

async function mcpCallTool(name, args) {
  const result = await mcpRequest('tools/call', { name, arguments: args || {} });
  // MCP tool results come back as a `content` array of blocks (text, etc.)
  const content = (result && result.content) || [];
  const text = content
    .map((b) => (b.type === 'text' ? b.text : JSON.stringify(b)))
    .join('\n');
  return { text, isError: !!(result && result.isError) };
}

// ---------------------------------------------------------------------------
// Anthropic Messages API (direct from the browser, BYOK)
// ---------------------------------------------------------------------------
async function callClaude(messages) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': state.apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: state.model,
      max_tokens: 1024,
      messages,
      tools: state.tools.length ? state.tools : undefined,
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error((err.error && err.error.message) || `Anthropic API returned ${res.status}`);
  }
  return res.json();
}

// ---------------------------------------------------------------------------
// UI plumbing
// ---------------------------------------------------------------------------
function addMessage(role, text) {
  const div = document.createElement('div');
  div.className = `msg ${role}`;
  div.textContent = text;
  el.messages.appendChild(div);
  el.messages.scrollTop = el.messages.scrollHeight;
  return div;
}

function setStatus(text, kind) {
  el.connectStatus.textContent = text;
  el.connectStatus.className = `status ${kind || ''}`;
}

el.connectBtn.addEventListener('click', async () => {
  const key = el.apiKey.value.trim();
  const url = el.mcpUrl.value.trim();

  if (!key) return setStatus('Add your Anthropic API key first.', 'err');
  if (!url) return setStatus('Add an MCP server URL first.', 'err');

  state.apiKey = key;
  state.model = el.model.value;

  el.connectBtn.disabled = true;
  setStatus('Connecting to MCP server…');
  pulse(el.nodeMcp);

  try {
    const tools = await mcpConnect(url);
    state.connected = true;
    setStatus(`Connected. ${tools.length} tool(s) available.`, 'ok');

    el.toolsUl.innerHTML = '';
    tools.forEach((t) => {
      const li = document.createElement('li');
      li.innerHTML = `${t.name}<span>${t.description || 'No description provided.'}</span>`;
      el.toolsUl.appendChild(li);
    });
    el.toolsList.hidden = tools.length === 0;

    addMessage('system', `Wired up to ${url} — ${tools.length} tool(s) ready. Ask away.`);
  } catch (e) {
    setStatus(`Connection failed: ${e.message}`, 'err');
    addMessage('error', `Could not connect to the MCP server: ${e.message}`);
  } finally {
    el.connectBtn.disabled = false;
  }
});

el.form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = el.input.value.trim();
  if (!text) return;

  if (!state.apiKey) {
    addMessage('error', 'Add your Anthropic API key and hit "Wire it up" first.');
    return;
  }

  el.input.value = '';
  addMessage('user', text);
  pulse(el.nodeYou);
  state.history.push({ role: 'user', content: text });

  el.sendBtn.disabled = true;
  try {
    await runTurn();
  } catch (err) {
    addMessage('error', `Something went wrong: ${err.message}`);
  } finally {
    el.sendBtn.disabled = false;
  }
});

// One "turn" may involve several LLM <-> MCP round trips if the model
// chains multiple tool calls before giving a final answer.
async function runTurn() {
  const thinking = addMessage('assistant', '…thinking');
  fire(el.wire1);
  pulse(el.nodeLlm);

  // eslint-disable-next-line no-constant-condition
  while (true) {
    const response = await callClaude(state.history);
    const contentBlocks = response.content || [];

    const toolUses = contentBlocks.filter((b) => b.type === 'tool_use');
    const textBlocks = contentBlocks.filter((b) => b.type === 'text');

    if (response.stop_reason === 'tool_use' && toolUses.length) {
      // Show the model's reasoning text (if any) before it reaches for a tool
      if (textBlocks.length) {
        thinking.textContent = textBlocks.map((b) => b.text).join('\n');
      }

      state.history.push({ role: 'assistant', content: contentBlocks });

      fire(el.wire2);
      pulse(el.nodeMcp);

      const toolResults = [];
      for (const call of toolUses) {
        addMessage('tool', `→ calling tool "${call.name}" ${JSON.stringify(call.input)}`);
        try {
          const result = await mcpCallTool(call.name, call.input);
          addMessage('tool', `← ${call.name} result: ${result.text.slice(0, 400)}`);
          toolResults.push({
            type: 'tool_result',
            tool_use_id: call.id,
            content: result.text,
            is_error: result.isError,
          });
        } catch (e) {
          addMessage('tool', `← ${call.name} failed: ${e.message}`);
          toolResults.push({
            type: 'tool_result',
            tool_use_id: call.id,
            content: `Error calling tool: ${e.message}`,
            is_error: true,
          });
        }
      }

      state.history.push({ role: 'user', content: toolResults });
      pulse(el.nodeLlm);
      continue; // send the tool results back to Claude for the next step
    }

    // Final answer
    const finalText = textBlocks.map((b) => b.text).join('\n') || '(no text response)';
    thinking.textContent = finalText;
    state.history.push({ role: 'assistant', content: contentBlocks });
    return;
  }
}

// Autosize the textarea a little
el.input.addEventListener('input', () => {
  el.input.style.height = 'auto';
  el.input.style.height = Math.min(el.input.scrollHeight, 120) + 'px';
});
el.input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    el.form.requestSubmit();
  }
});
