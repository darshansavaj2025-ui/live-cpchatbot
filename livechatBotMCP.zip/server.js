// A tiny, live MCP server for the NCI individual exercise.
//
// Ships 3 example tools (get_time, roll_dice, calculator) over the
// Streamable HTTP transport, with CORS enabled so a static site (like the
// chatbot deployed to GitHub Pages) can call it directly from the browser.
//
// Run locally:   npm install && npm start        -> http://localhost:3000/mcp
// Deploy free:   Render, Railway, Fly.io, Cyclic, or a Cloudflare Worker all
//                work fine here — just point the chatbot at
//                https://<your-deployed-url>/mcp

import express from 'express';
import cors from 'cors';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';

const PORT = process.env.PORT || 3000;

function buildServer() {
  const server = new McpServer({ name: 'nci-demo-tools', version: '1.0.0' });

  server.registerTool(
    'get_time',
    {
      title: 'Get current time',
      description: 'Returns the current server date and time in ISO format.',
      inputSchema: {},
    },
    async () => ({
      content: [{ type: 'text', text: new Date().toISOString() }],
    })
  );

  server.registerTool(
    'roll_dice',
    {
      title: 'Roll dice',
      description: 'Rolls N six-sided dice and returns the results.',
      inputSchema: {
        count: z.number().int().min(1).max(20).describe('How many dice to roll (1-20)'),
      },
    },
    async ({ count }) => {
      const rolls = Array.from({ length: count }, () => 1 + Math.floor(Math.random() * 6));
      return {
        content: [{ type: 'text', text: `Rolled: ${rolls.join(', ')} (total ${rolls.reduce((a, b) => a + b, 0)})` }],
      };
    }
  );

  server.registerTool(
    'calculator',
    {
      title: 'Calculator',
      description: 'Evaluates a simple arithmetic expression, e.g. "12 * (3 + 4)".',
      inputSchema: {
        expression: z.string().describe('An arithmetic expression using + - * / ( )'),
      },
    },
    async ({ expression }) => {
      if (!/^[\d\s+\-*/().]+$/.test(expression)) {
        return { content: [{ type: 'text', text: 'Invalid expression: only digits and + - * / ( ) are allowed.' }], isError: true };
      }
      try {
        // eslint-disable-next-line no-new-func
        const result = Function(`"use strict"; return (${expression});`)();
        return { content: [{ type: 'text', text: String(result) }] };
      } catch (e) {
        return { content: [{ type: 'text', text: `Could not evaluate expression: ${e.message}` }], isError: true };
      }
    }
  );

  return server;
}

const app = express();
app.use(cors({
  origin: '*', // tighten this to your GitHub Pages URL once deployed
  exposedHeaders: ['Mcp-Session-Id'],
  allowedHeaders: ['Content-Type', 'Mcp-Session-Id'],
}));
app.use(express.json());

app.get('/', (_req, res) => res.send('NCI demo MCP server is running. POST to /mcp.'));

// Stateless mode: a fresh server + transport per request is simplest and
// works well for a small class exercise (no session bookkeeping needed).
app.post('/mcp', async (req, res) => {
  try {
    const server = buildServer();
    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: undefined,
    });
    res.on('close', () => {
      transport.close();
      server.close();
    });
    await server.connect(transport);
    await transport.handleRequest(req, res, req.body);
  } catch (err) {
    console.error('Error handling MCP request:', err);
    if (!res.headersSent) {
      res.status(500).json({
        jsonrpc: '2.0',
        error: { code: -32603, message: 'Internal server error' },
        id: null,
      });
    }
  }
});

app.listen(PORT, () => {
  console.log(`MCP server listening on http://localhost:${PORT}/mcp`);
});
